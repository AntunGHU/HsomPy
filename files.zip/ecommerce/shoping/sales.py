# from ..customer import contact
# from ecommerce.customer import contact

print("Sales initialized")


def calculate_shipping():
    print("CSH")


def calc_tax():
    print("Tax")


# contact.contact_customer()
