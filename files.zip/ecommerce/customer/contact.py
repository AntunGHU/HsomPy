def contact_customer():
    print("Kontaktiran!")
